from flask import Flask, request, jsonify, render_template
from faker import Faker
from twilio.jwt.access_token import AccessToken
from twilio.jwt.access_token.grants import SyncGrant


app = Flask(__name__)
fake = Faker()


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/token')
def generate_token():
    TWILIO_ACCOUNT_SID = 'AC569177be929bf89f1444e284ba0ebd8d'
    TWILIO_SYNC_SERVICE_SID = 'ISd7c3d0c4cf7dfab44937d08d7f4ac819'
    TWILIO_API_KEY = 'SK3c7e4e2e5ddd4dfb485e03e2bbdcd2f0'
    TWILIO_API_SECRET = 'ZXcWnEuuKIotkB4BP7D9Zq5JKAMlLwDK'

    username = request.args.get('username', fake.user_name())

    token = AccessToken(TWILIO_ACCOUNT_SID, TWILIO_API_KEY, TWILIO_API_SECRET, identity=username)

    sync_grant_access = SyncGrant(TWILIO_SYNC_SERVICE_SID)
    token.add_grant(sync_grant_access)
    return jsonify(identity=username, token=token.to_jwt())



if __name__ == "__main__":
    app.run()

